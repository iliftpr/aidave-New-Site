# Install — The Fable Method

The Fable Method is a Claude Code *skill*: one file that changes how your AI
coding agent works. No API key, no dependency, no build step.

## 1. Drop it in

Unzip this archive and move the `fable-mode` folder into your Claude Code skills
directory so the file lands here:

    ~/.claude/skills/fable-mode/SKILL.md

On Windows that's `C:\Users\<you>\.claude\skills\fable-mode\SKILL.md`.

## 2. Reload

Restart Claude Code (or start a new session) so it picks up the new skill.

## 3. Run it

- Say **"fable mode"** (or "use the fable method") to turn it on for a task, or
- Let it trigger itself — it activates automatically on work where the first idea
  might be wrong: multi-step builds, debugging, and research with claims.

Works on Opus or Sonnet. It layers on top of your existing skills — it changes
*how* the agent works, not *what* it can do.

## What it does

Runs every hard task through five checkpoints, in order: **Scope → Evidence →
Adversarial reasoning → Verify → Report.** See README.md for the short version,
or read SKILL.md for the full method.

Learn more: https://ilift.com/fable
