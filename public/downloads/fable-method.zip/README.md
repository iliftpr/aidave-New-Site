# The Fable Method

A working discipline for AI coding agents, written as a single Claude Code skill.
It makes an agent slow down at the right moments — so it hallucinates less and
stops declaring unverified work "done."

## The five checkpoints

1. **Scope before work** — define what "done" means and how you'll check it.
2. **Evidence before reasoning** — open the real file; trust primary sources over blogs.
3. **Reason adversarially** — attack the answer before shipping it.
4. **Verify before declaring done** — "it ran" isn't "it's right."
5. **Report calibrated** — lead with the answer; separate proven from assumed.

Plus standing habits, a "team" of tools wired in at the right checkpoint, and a set of
"smells" that signal a step got skipped.

## Who it's for

- **Builders** on Claude Code who want an agent that grounds, verifies, and reports honestly.
- **Operators** who run their business on AI and need work that actually holds up.

## Install

See INSTALL.md. Short version: drop the `fable-mode` folder into
`~/.claude/skills/` and say "fable mode."

Free. One file. Built by Dave Gakshteyn / ILift — https://ilift.com/fable
